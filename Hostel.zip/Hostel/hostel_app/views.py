from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth.hashers import make_password
from .models import *
from django.contrib import messages
from django.db import connection
from django.contrib.auth import logout
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
from django.db.models import Q

cursor = connection.cursor()

def index(request):
    
    return render(request,'home.html')

def home(request):
    if 'user' in request.session:
        user = request.session['user']
        data = Login.objects.get(username=user)
        if data.role == 'admin':
            return render(request,'master/home.html')
        elif data.role == 'student':
            return redirect('/student_home')
        elif data.role == 'matron':
            return render(request, 'matron/home.html')
        elif data.role == 'warden':
            return render(request, 'warden/home.html')
        else:
            return redirect('/home')
    else:
        return render(request,'home.html')

def login(request):
    if request.method == 'POST':
        use = request.POST['username']
        pas = request.POST['password']
        try:
            data = Login.objects.get(username=use,password= pas)
            if data.password == pas and data.role =='admin':
                request.session['user'] = use
                request.session['log_id'] = data.log_id
                
                return redirect('/home')
            else:
                messages.success(request, 'Invalid Username Or Password...')
                return redirect('/login/')
        except Exception:
            messages.success(request, 'Invalid Username Or Password...')
            return redirect('/login/')
    else:
        return render(request,'admin_login.html')
        
def student_login(request):
    if request.method == 'POST':
        use = request.POST['username']
        pas = request.POST['password']
        try:
            data = Login.objects.get(username=use,password= pas)
            if data.password == pas and data.role =='student':
                request.session['user'] = use
                request.session['log_id'] = data.log_id
                
                return redirect('/home')
            else:
                messages.success(request, 'Invalid Username Or Password...')
                return redirect('/student_login/')
        except Exception:
            messages.success(request, 'Invalid Username Or Password...')
            return redirect('/student_login/')
    else:
        return render(request,'login.html')
        
def matron_login(request):
    if request.method == 'POST':
        use = request.POST['username']
        pas = request.POST['password']
        try:
            data = Login.objects.get(username=use,password=pas)
            if data.password == pas and data.role =='matron':
                request.session['user'] = use
                request.session['log_id'] = data.log_id
                
                return redirect('/home')
            else:
                messages.success(request, 'Invalid Username Or Password...')
                return redirect('/matron_login/')
        except Exception:
            messages.success(request, 'Invalid Username Or Password...')
            return redirect('/matron_login/')
    else:
        return render(request,'matron_login.html')
        

def warden_login(request):
    if request.method == 'POST':
        use = request.POST['username']
        pas = request.POST['password']
        try:
            data = Login.objects.get(username=use,password= pas)
            if data.password == pas and data.role =='warden':
                request.session['user'] = use
                request.session['log_id'] = data.log_id
                
                return redirect('/home')
            else:
                messages.success(request, 'Invalid Username Or Password...')
                return redirect('/warden_login/')
        except Exception:
            messages.success(request, 'Invalid Username Or Password...')
            return redirect('/warden_login/')
    else:
        return render(request,'warden_login.html')
        
    

# def student_home(request):
#     if 'user' in request.session:
#         st = request.session['log_id']
#         data = Students.objects.filter(log_id=st)
        
#         from datetime import date,datetime,timedelta
#         n=0
#         msg=''
#         try:
#             m = Payment.objects.filter(student_id=st).order_by('-p_id').first()
#             if m:
#                 s = date.today()
#                 v=m.next_pay_date

#                 o=datetime.strptime(v,"%Y-%m-%d").date()
#                 a = o - timedelta(days=5)
#                 # n = s-a
#                 t = date.today()
                
#                 if a<t:
#                     msg = v
#                 else:
#                     msg = ''
#             else:
#                 l = Students.objects.get(log_id=st)
#                 v = l.join_date
#                 o=datetime.strptime(v,"%Y-%m-%d").date()
#                 a = o + timedelta(days=25)
#                 h = o + timedelta(days=30)
#                 t = date.today()
                
#                 if a<t:
#                     msg = h
#                 else:
#                     msg = ''
                
#         except Exception:
#             return HttpResponse("no_result")
            
        
#         return render(request, 'student/home.html',{'data':data,'msg':msg})

#     else:
#         return redirect('/home')


def student_home(request):
    if 'user' in request.session:
        st = request.session['log_id']
        data = Students.objects.filter(log_id=st)
        
        from datetime import date,timedelta,datetime
        msg=''
        t = date.today()
        pa = Payment.objects.filter(student_id=st).last()

        if pa is None:
            jo = Students.objects.get(log_id=st)
            m = datetime.strptime(jo.join_date,"%Y-%m-%d").date()
            dt = m + timedelta(days=25)

            if dt<t:
                msg = m + timedelta(days=30)
            else:
                msg = None
        else:
            m = datetime.strptime(pa.next_pay_date,"%Y-%m-%d").date()
            dt = m - timedelta(days=5)
            if dt<t:
                msg = pa.next_pay_date
            else:
                msg = None

        return render(request, 'student/home.html',{'data':data,'msg':msg})

    else:
        return redirect('/home')





#----------------------Master---------------------------

def add_batch(request):
    if 'user' in request.session:
        if request.method == 'POST':
            batch = request.POST['batch']
            Batch.objects.create(batch=batch)
            messages.success(request,'batch added successfully.....')
            return redirect('/add_batch')
        else:
            d = Batch.objects.all()
            return render(request,'master/add_batch.html',{'data':d})
    else:
        return redirect('/home')
    
def up_batch(request,b_id):
    if 'user' in request.session:
        data=Batch.objects.filter(b_id=b_id)
        return render(request,'master/update_batch.html',{'data':data})
    else:
        return redirect('/home')
    
def update_batch(request):
    if 'user' in request.session:
        if request.method == 'POST':
            b_id = request.POST['b_id']
            batch = request.POST['batch']
            Batch.objects.filter(b_id=b_id).update(batch=batch)
            messages.success(request, 'Updated successfully.....')
            return redirect('/add_batch')
        else: 
            return redirect('/add_batch')
    else:
        return redirect('/home')
    
def delete_batch(request,b_id):
    if 'user' in request.session:
        data  = Batch.objects.get(b_id=b_id)
        data.delete()
        messages.success(request, 'Batch deleted successfully.....')
        return redirect ('/add_batch')
    else:
        return redirect('/home')
    
def add_course(request):
    if 'user' in request.session:
        if request.method == 'POST':
            course = request.POST['course']
            Course.objects.create(course=course)
            messages.success(request,'course added successfully.....')
            return redirect('/add_course')
        else:
            d = Course.objects.all()
            return render(request,'master/add_course.html',{'data':d})
    else:
        return redirect('/home')
    
def up_course(request,c_id):
    if 'user' in request.session:
        data=Course.objects.filter(c_id=c_id)
        return render(request,'master/update_course.html',{'data':data})
    else:
        return redirect('/home')
    
def update_course(request):
    if 'user' in request.session:
        if request.method == 'POST':
            c_id = request.POST['c_id']
            course = request.POST['course']
            Course.objects.filter(c_id=c_id).update(course=course)
            messages.success(request, 'Updated successfully.....')
            return redirect('/add_course')
        else: 
            return redirect('/add_course')
    else:
        return redirect('/home')
    
def delete_course(request,c_id):
    if 'user' in request.session:
        data  = Course.objects.get(c_id=c_id)
        data.delete()
        messages.success(request, 'course deleted successfully.....')
        return redirect ('/add_course')
    else:
        return redirect('/home')
    
def add_hostel(request):
    if 'user' in request.session:
        if request.method == 'POST':
            hostel = request.POST['hostel']
            Hostel.objects.create(hostel=hostel)
            messages.success(request,'hostel added successfully.....')
            return redirect('/add_hostel')
        else:
            d = Hostel.objects.all()
            return render(request,'master/add_hostel.html',{'data':d})
    else:
        return redirect('/home')
    
def up_hostel(request,h_id):
    if 'user' in request.session:
        data = Hostel.objects.filter(h_id=h_id)
        return render(request,'master/update_hostel.html',{'data':data})
    else:
        return redirect('/home')
    
def update_hostel(request):
    if 'user' in request.session:
        if request.method == 'POST':
            h_id = request.POST['h_id']
            hostel = request.POST['hostel']
            Hostel.objects.filter(h_id=h_id).update(hostel=hostel)
            messages.success(request, 'Updated successfully.....')
            return redirect('/add_hostel')
        else: 
            return redirect('/add_hostel')
    else:
        return redirect('/home')
    
def delete_hostel(request,h_id):
    if 'user' in request.session:
        data  = Hostel.objects.get(h_id=h_id)
        data.delete()
        messages.success(request, 'hostel deleted successfully.....')
        return redirect ('/add_hostel')
    else:
        return redirect('/home')
    
def add_room(request):
    if 'user' in request.session:
        if request.method == "POST":
            h_id = request.POST['h_id']
            room_no=request.POST['room_no']
            beds=request.POST['beds']
            floor_no=request.POST['floor_no']
            vacancy=request.POST['vacancy']

            Rooms.objects.create(room_number=room_no,beds=beds,floor_number=floor_no,vacancy=vacancy,h_id=h_id)
            messages.success(request, 'Room Added successfully.....')
            return redirect('/add_room')
        else:
            data = Hostel.objects.all()
            data2 = Rooms.objects.all().select_related('h')
            return render(request,'master/add_room.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')

def up_room(request,r_id):
    if 'user' in request.session:
        data = Rooms.objects.filter(r_id=r_id).select_related('h')
        data2 = Hostel.objects.all()
        return render(request,'master/update_room.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')
    
def update_room(request):
    if 'user' in request.session:
        if request.method == 'POST':
            r_id = request.POST['r_id']
            h_id = request.POST['h_id']
            room_no=request.POST['room_no']
            beds=request.POST['beds']
            floor_no=request.POST['floor_no']
            vacancy=request.POST['vacancy']
            Rooms.objects.filter(r_id=r_id).update(room_number=room_no,beds=beds,floor_number=floor_no,vacancy=vacancy,h_id=h_id)
            messages.success(request, 'Updated successfully.....')
            return redirect('/add_room')
        else: 
            return redirect('/add_room')
    else:
        return redirect('/home')
    
def delete_room(request,r_id):
    if 'user' in request.session:
        data  = Rooms.objects.get(r_id=r_id)
        data.delete()
        messages.success(request, 'Room deleted successfully.....')
        return redirect ('/add_room')
    else:
        return redirect('/home')
    


def add_warden(request):
    if 'user' in request.session:
        if request.method == 'POST':
            name = request.POST['name']
            email = request.POST['email']
            phone = request.POST['phone']
            address = request.POST['address']
            username = request.POST['username']
            password = request.POST['password']

            image=request.FILES['image']
            obj = FileSystemStorage()
            fl = obj.save(image.name,image)
            img = obj.url(fl)


            try:
                Login.objects.get(username=username)
                messages.success(request, 'This Username is already Exist.....')
                return redirect('/add_warden')
            except Exception:
                Login.objects.create(username=username,password=password,role='warden',status=1)
                d = Login.objects.get(username=username)

                Warden.objects.create(name=name,email=email,phone=phone,address=address,image=img,log_id=d.log_id)
                messages.success(request, 'Registered successfully.....')
                return redirect('/add_warden')
        else:
            data = Warden.objects.all()
            return render(request, 'master/add_warden.html',{'data':data})
    else:
        return redirect('/home')

def delete_warden(request,w_id):
    if 'user' in request.session:
        data  = Login.objects.get(log_id=w_id)
        data.delete()
        messages.success(request, 'Deleted successfully.....')
        return redirect ('/add_warden')
    else:
        return redirect('/home')

def add_matron(request):
    if 'user' in request.session:
        if request.method == 'POST':
            h_id = request.POST['h_id']
            name = request.POST['name']
            email = request.POST['email']
            phone = request.POST['phone']
            address = request.POST['address']
            password = request.POST['password']
            username = request.POST['username']

            image=request.FILES['image']
            obj = FileSystemStorage()
            fl = obj.save(image.name,image)
            img = obj.url(fl)


            try:
                Login.objects.get(username=username)
                messages.success(request, 'This Username is already Exist.....')
                return redirect('/add_matron')
            except Exception:
                Login.objects.create(username=username,password=password,role='matron',status=1)
                d = Login.objects.get(username=username)

                Matron.objects.create(name=name,email=email,phone=phone,address=address,image=img,log_id=d.log_id,hostel_id=h_id)
                messages.success(request, 'Registered successfully.....')
                return redirect('/add_matron')
        else:
            cursor.execute("select m.*,h.hostel from tb_matron as m inner join tb_hostel as h on m.hostel_id=h.h_id")
            data = cursor.fetchall()
            data2 = Hostel.objects.all()
            return render(request, 'master/add_matron.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')
    
def delete_matron(request,m_id):
    if 'user' in request.session:
        data  = Login.objects.get(log_id=m_id)
        data.delete()
        messages.success(request, 'Deleted successfully.....')
        return redirect ('/add_matron')
    else:  
        return redirect('/home')
    












def add_student(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        password = request.POST['password']
        batch = request.POST['batch']
        course = request.POST['course']
        guardian_name = request.POST['guardian_name']
        guardian_number = request.POST['guardian_number']
        username = request.POST['username']
        room_no = request.POST['room_no']
        h_id = request.POST['h_id']


        image = request.FILES['image']
        obj = FileSystemStorage()
        fl = obj.save(image.name,image)
        img = obj.url(fl)

        id_proof=request.FILES['id_proof']
        obj1 = FileSystemStorage()
        f2 = obj1.save(id_proof.name,id_proof)
        pro = obj.url(f2)

        try:
            Login.objects.get(username=username)
            messages.success(request, 'This Username is already Exist.....')
            return redirect('/add_student')
        except Exception:
            Login.objects.create(username=username,password=password,role='student',status=0)
            d = Login.objects.get(username=username)

            from datetime import date

            t = date.today()

            Students.objects.create(name=name,email=email,phone=phone,address=address,batch=batch,course=course,guardian_name=guardian_name,guardian_number=guardian_number,id_proof=pro,image=img,log_id=d.log_id,hostel_id=h_id,room_number=room_no,join_date=t)
            
            #  .objects.create(student_id=d.log_id,last_pay_date=t,next_pay_date=npd,amount=amount,status='paid')
           
            d = Rooms.objects.get(h_id=h_id,room_number=room_no)
            sub = int(d.vacancy)-1
            if sub == 0:
                Rooms.objects.filter(h_id=h_id,room_number=room_no).update(vacancy=0)
            else:
                Rooms.objects.filter(h_id=h_id,room_number=room_no).update(vacancy=sub)

            messages.success(request, 'Registered successfully.....')
            return redirect('/add_student')
    else:
        bat = Batch.objects.all()
        cou = Course.objects.all()
        hos = Hostel.objects.all()
        data = Hostel_fee.objects.all()
        return render(request,'warden/add_student.html',{'bat':bat,'cou':cou,'hos':hos,'data':data})

    
def add_fee(request):
    if 'user' in request.session:
        if request.method == 'POST':
            electricity = request.POST['electricity']
            water = request.POST['water']
            rent = request.POST['rent']

            total = int(electricity)+int(water)+int(rent)

            Hostel_fee.objects.create(electricity=electricity,water=water,rent=rent,total=total)
            messages.success(request, 'Added successfully..')
            return redirect('/add_fee')
        else:
            data = Hostel_fee.objects.all()
            return render(request, 'master/add_fee.html',{'data':data})
    else:
        return redirect('/home')
    
def up_fee(request,f_id):
    if 'user' in request.session:
        data = Hostel_fee.objects.filter(fee_id=f_id)
        return render(request,'master/update_fee.html',{'data':data})
    else:
        return redirect('/home')

def update_fee(request):
    if 'user' in request.session:
        if request.method == 'POST':
            f_id = request.POST['f_id']
            electricity = request.POST['electricity']
            water = request.POST['water']
            rent = request.POST['rent']

            total = int(electricity)+int(water)+int(rent)

            Hostel_fee.objects.filter(fee_id=f_id).update(electricity=electricity,water=water,rent=rent,total=total)
            messages.success(request, 'Updated successfully.....')
            return redirect('/add_fee')
        else:
            data = Hostel_fee.objects.all()
            return render(request, 'master/update_fee.html',{'data':data})
    else:
        return redirect('/home')



def delete_fee(request,f_id):
    if 'user' in request.session:
        data  = Hostel_fee.objects.get(fee_id=f_id)
        data.delete()
        messages.success(request, 'Deleted successfully.....')
        return redirect ('/add_fee')
    else:  
        return redirect('/home')

def student_list(request):
    if 'user' in request.session:
        data=Students.objects.all().select_related('log')
        data2 = Hostel.objects.all()
        data3 = Rooms.objects.all()
        return render(request,'master/student_list.html',{'data':data,'data2':data2,'data3':data3})
    else:
        return redirect('/home')
    
def leave_request_w(request):
    if 'user' in request.session:
        cursor.execute("select s.*,r.hostel,l.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_leave as l on l.student_id=s.log_id order by l.l_id desc")
        data = cursor.fetchall()
        return render(request,'warden/leave_request.html',{'data':data})
    else:
        return redirect('/home')


def approve_leave(request,l_id):
    if 'user' in request.session:
        Leave.objects.filter(l_id=l_id).update(status="Leave Approved")
        return redirect('/leave_request_w')
    else:
        return redirect('/home')
    
def reject_leave(request,l_id):
    if 'user' in request.session:
        Leave.objects.filter(l_id=l_id).update(status="Leave Rejected")
        return redirect('/leave_request_w')
    else:
        return redirect('/home')
    
def outpass_request_w(request):
    if 'user' in request.session:
        cursor.execute("select s.*,r.hostel,o.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_outpass as o on o.student_id=s.log_id order by o.o_id desc")
        data = cursor.fetchall()
        return render(request,'warden/outpass_request.html',{'data':data})
    else:
        return redirect('/home')


def approve_outpass(request,o_id):
    if 'user' in request.session:
        Outpass.objects.filter(o_id=o_id).update(status="Outpass Approved")
        return redirect('/outpass_request_w')
    else:
        return redirect('/home')
    
def reject_outpass(request,o_id):
    if 'user' in request.session:
        Outpass.objects.filter(o_id=o_id).update(status="Outpass Rejected")
        return redirect('/outpass_request_w')
    else:
        return redirect('/home')

def reset_password_a(request):
    if 'log_id' in request.session:
        log_id = request.session['log_id']
        if request.method == 'POST':
            opas = request.POST['old_password']
            password = request.POST['password']
            try:
                data = Login.objects.get(log_id=log_id)
                if data.password == opas:
                    Login.objects.filter(log_id=log_id).update(password=password)
                    messages.success(request, 'Your Password has been Reset successfully.....')
                    return redirect('/reset_password_a')
                else:
                    messages.success(request, 'Enter valid current password....!')
                    return redirect('/reset_password_a')
            except Exception:
                messages.success(request, 'Invalid User.....')
                return redirect('/reset_password_a')
        else:
            return render(request,'master/reset_password.html')
    else:
        return redirect('/home')

#--------------------student---------------------

def view_fees(request):
    if 'user' in request.session:
        data = Hostel_fee.objects.all()
        return render(request,'student/view_fees.html',{'data':data})
    else:
        return redirect('/home')


def complaint(request):
    if 'user' in request.session:
        if request.method == 'POST':
            complaint = request.POST['complaint']
            d = Students.objects.get(log_id=request.session['log_id'])
            
            Complaints.objects.create(complaint=complaint,student_id=request.session['log_id'],reply='0',hostel_id=d.hostel_id)
            messages.success(request, 'submitted Successfully..')
            return redirect('/complaint')
        else:
            return render(request,'student/complaint.html')
    else:
        return redirect('/home')

def view_reply(request):
    if 'user' in request.session:
        data = Complaints.objects.filter(student_id=request.session['log_id'])
        return render(request,'student/view_complaint.html',{'data':data})
    else:
        return redirect('/home')

def outpass_request(request):
    if 'user' in request.session:
        if request.method == 'POST':
            date = request.POST['date']
            time = request.POST['time']
            description = request.POST['description']

            
            d = Students.objects.get(log_id=request.session['log_id'])
            
            Outpass.objects.create(date=date,time=time,description=description,student_id=request.session['log_id'],status='Request sent..',hostel_id=d.hostel_id)
            messages.success(request, 'Request sended Successfully')
            return redirect('/outpass_request')
        else:
            return render(request,'student/outpass.html')
    else:
        return redirect('/home')


def view_outpass(request):
    if 'user' in request.session:
        data = Outpass.objects.filter(student_id=request.session['log_id'])
        return render(request,'student/view_outpass.html',{'data':data})
    else:
        return redirect('/home')
    
def leave_request(request):
    if 'user' in request.session:
        if request.method == 'POST':
            date = request.POST['date']
            no_days = request.POST['no_days']
            description = request.POST['description']

            d = Students.objects.get(log_id=request.session['log_id'])
            
            Leave.objects.create(date=date,no_of_days=no_days,description=description,student_id=request.session['log_id'],status='Request sent..',hostel_id=d.hostel_id)
            messages.success(request, 'Request Sended..')
            return redirect('/leave_request')
        else:
            return render(request,'student/leave_request.html')
    else:
        return redirect('/home')
    
def view_leave(request):
    if 'user' in request.session:
        data = Leave.objects.filter(student_id=request.session['log_id'])
        return render(request,'student/view_leave.html',{'data':data})
    else:
        return redirect('/home')
    
def scan_qr(request):
    if 'user' in request.session:
        st = request.session['log_id']
        from datetime import date,datetime,timedelta
        msg=''
        t = date.today()
        pa = Payment.objects.filter(student_id=st).last()

        if pa is None:
            jo = Students.objects.get(log_id=st)
            m = datetime.strptime(jo.join_date,"%Y-%m-%d").date()
            dt = m + timedelta(days=25)

            if dt<t:
                msg = None
            else:
                m = m + timedelta(days=30)
                msg = "Your hostel fee payement date is "+str(m)
                
        else:
            m = datetime.strptime(pa.next_pay_date,"%Y-%m-%d").date()
            dt = m - timedelta(days=5)
            if dt<t:
                msg = None 
            else:
                msg = "You Already Paid The Hostel on "+pa.last_pay_date

        return render(request,'student/scan_qr.html',{'msg':msg})
    else:
        return redirect('/home')


def payment(request):
    from datetime import date,datetime,timedelta
    if 'user' in request.session:
        st = request.session['log_id']
        if request.method == 'POST':
            amount = request.POST['amount']
            n = request.POST['npd']
         
            
            t = date.today()

            it = datetime.strptime(n,'%Y-%m-%d').date()
            
            npd = it + timedelta(30)
            
            Payment.objects.create(student_id=st,last_pay_date=t,next_pay_date=npd,amount=amount,status='paid')
            messages.success(request, 'Paid Successfullly')
            return redirect('/payment')
        else:
            
            data2 = Hostel_fee.objects.all()
            data3 = Mess_Fee.objects.filter(student_id=st).last()
            
            msg=''
            t = date.today()
            pa = Payment.objects.filter(student_id=st).last()

            if pa is None:
                jo = Students.objects.get(log_id=st)
                m = datetime.strptime(jo.join_date,"%Y-%m-%d").date()
                dt = m + timedelta(days=25)
                v = str(m + timedelta(days=30))
                if dt<t:
                    msg = m + timedelta(days=30)
                else:
                    msg = None
            else:
                m = datetime.strptime(pa.next_pay_date,"%Y-%m-%d").date()
                dt = m - timedelta(days=5)
                v = str(m + timedelta(days=30))
                if dt<t:
                    msg = pa.next_pay_date
                else:
                    msg = None
        
            return render(request,'student/payment.html',{'data':v,'data2':data2,'data3':data3,'msg':msg})
    else:
        return redirect('/home')


def view_payments_s(request):
    if 'user' in request.session:
        st = request.session['log_id']
        
        data = Payment.objects.filter(student_id=st)
        d = Payment.objects.filter(student_id=st).last()
        return render(request,'student/view_payments.html',{'data':data,'d':d})
    else:
        return redirect('/home')
    

def student_list_a(request):
    if 'user' in request.session:
        cursor.execute("SELECT s.*,h.hostel FROM tb_student AS s INNER JOIN tb_hostel AS h ON s.hostel_id=h.h_id")
        data = cursor.fetchall()
        data2 = Hostel.objects.all()
        return render(request,'master/student_list.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')

def outpass_request_a(request):
    if 'user' in request.session:
        
        cursor.execute("select s.*,r.hostel,o.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_outpass as o on o.student_id=s.log_id order by o.o_id desc")
        data = cursor.fetchall()
        return render(request,'master/outpass_request.html',{'data':data})
    else:
        return redirect('/home')

def leave_request_a(request):
    if 'user' in request.session:
        
        cursor.execute("select s.*,r.hostel,l.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_leave as l on l.student_id=s.log_id order by l.l_id desc")
        data = cursor.fetchall()
        return render(request,'master/leave_request.html',{'data':data})
    else:
        return redirect('/home')
    
def view_payments_a(request):
    if 'user' in request.session:
        
        cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id")
        data = cursor.fetchall()
        return render(request,'master/view_payments.html',{'data':data})
    else:
        return redirect('/home')


def student_dues_a(request):
    if 'user' in request.session:
        
        # cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id where p.next_pay_date< CURDATE() and s.hostel_id="+str(d.hostel_id))
        cursor.execute("select s.*,p.last_pay_date,p.next_pay_date,h.hostel from (SELECT student_id,last_pay_date,MAX(next_pay_date) AS next_pay_date from tb_payment group by student_id)p inner join tb_student as s on p.student_id=s.log_id inner join tb_hostel as h on s.hostel_id=h.h_id where p.next_pay_date< CURDATE()")
        
        data = cursor.fetchall()
        return render(request,'master/student_dues.html',{'data':data})
    else:
        return redirect('/home')
    
def update_student(request):
    if 'user' in request.session:
        st = request.session['log_id']
        if request.method == 'POST':
            name = request.POST['name']
            email = request.POST['email']
            phone = request.POST['phone']
            address = request.POST['address']
            guardian_number = request.POST['guardian_number']
        
            


            if len(request.FILES) == 0:
                Students.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address,guardian_number=guardian_number)
                messages.success(request, 'Updated successfully.....')
                return redirect('/update_student')
            else:
                image = request.FILES['image']
                obj = FileSystemStorage()
                fl = obj.save(image.name,image)
                img = obj.url(fl)

                Students.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address,guardian_number=guardian_number,image=img)
                return redirect('/update_student')
            
        else:
            data = Students.objects.filter(log_id=st)
            return render(request,'student/profile.html',{'data':data})
    else:
        return redirect('/home')


def reset_password_s(request):
    if 'log_id' in request.session:
        log_id = request.session['log_id']
        if request.method == 'POST':
            opas = request.POST['old_password']
            password = request.POST['password']
            try:
                data = Login.objects.get(log_id=log_id)
                if data.password == opas:
                    Login.objects.filter(log_id=log_id).update(password=password)
                    messages.success(request, 'Your Password has been Reset successfully.....')
                    return redirect('/reset_password_s')
                else:
                    messages.success(request, 'Enter valid current password....!')
                    return redirect('/reset_password_s')
            except Exception:
                messages.success(request, 'Invalid User.....')
                return redirect('/reset_password_s')
        else:
            return render(request,'student/reset_password.html')
    else:
        return redirect('/home')
    


#-----------------Warden--------------------

def student_list_w(request):
    if 'user' in request.session:
        cursor.execute("SELECT s.*,h.hostel FROM tb_student AS s INNER JOIN tb_hostel AS h ON s.hostel_id=h.h_id")
        data = cursor.fetchall()
        data2 = Hostel.objects.all()
        return render(request,'warden/student_list.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')

def view_payments_w(request):
    if 'user' in request.session:
        
        cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id")
        data = cursor.fetchall()
        return render(request,'warden/view_payments.html',{'data':data})
    else:
        return redirect('/home')


def student_dues_w(request):
    if 'user' in request.session:
        
        # cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id where p.next_pay_date< CURDATE() and s.hostel_id="+str(d.hostel_id))
        cursor.execute("select s.*,p.last_pay_date,p.next_pay_date,h.hostel from (SELECT student_id,last_pay_date,MAX(next_pay_date) AS next_pay_date from tb_payment group by student_id)p inner join tb_student as s on p.student_id=s.log_id inner join tb_hostel as h on s.hostel_id=h.h_id where p.next_pay_date< CURDATE()")
        
        data = cursor.fetchall()
        data2 = Hostel.objects.all()
        return render(request,'warden/student_dues.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')

def warden_profile(request):
    if 'user' in request.session:
        st = request.session['log_id']
        if request.method == 'POST':
            name = request.POST['name']
            email = request.POST['email']
            phone = request.POST['phone']
            address = request.POST['address']
            
        
            if len(request.FILES) == 0:
                Warden.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address)
                messages.success(request, 'Updated successfully.....')
                return redirect('/warden_profile')
            else:
                image = request.FILES['image']
                obj = FileSystemStorage()
                fl = obj.save(image.name,image)
                img = obj.url(fl)

                Warden.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address,image=img)
                return redirect('/warden_profile')
            
        else:
            data = Warden.objects.filter(log_id=st)
            return render(request,'warden/profile.html',{'data':data})
    else:
        return redirect('/home')

def reset_password_w(request):
    if 'log_id' in request.session:
        log_id = request.session['log_id']
        if request.method == 'POST':
            opas = request.POST['old_password']
            password = request.POST['password']
            try:
                data = Login.objects.get(log_id=log_id)
                if data.password == opas:
                    Login.objects.filter(log_id=log_id).update(password=password)
                    messages.success(request, 'Your Password has been Reset successfully.....')
                    return redirect('/reset_password_w')
                else:
                    messages.success(request, 'Enter valid current password....!')
                    return redirect('/reset_password_w')
            except Exception:
                messages.success(request, 'Invalid User.....')
                return redirect('/reset_password_w')
        else:
            return render(request,'warden/reset_password.html')
    else:
        return redirect('/home')



#-------------------Matron--------------------

def matron_profile(request):
    if 'user' in request.session:
        st = request.session['log_id']
        if request.method == 'POST':
            name = request.POST['name']
            email = request.POST['email']
            phone = request.POST['phone']
            address = request.POST['address']
            
        
            if len(request.FILES) == 0:
                Matron.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address)
                messages.success(request, 'Updated successfully.....')
                return redirect('/matron_profile')
            else:
                image = request.FILES['image']
                obj = FileSystemStorage()
                fl = obj.save(image.name,image)
                img = obj.url(fl)

                Matron.objects.filter(log_id=st).update(name=name,email=email,phone=phone,address=address,image=img)
                return redirect('/matron_profile')
        else:
            data = Matron.objects.filter(log_id=st)
            return render(request,'matron/profile.html',{'data':data})
    else:
        return redirect('/home')


def student_list_m(request):
    if 'user' in request.session:
        d = Matron.objects.get(log_id=request.session['log_id'])
        # cursor.execute("select s.*,b.booking_date,r.room_number from tb_student as s inner join tb_booking as b on s.log_id=b.Student_id inner join tb_room_vacancy as r on b.room_id=r.r_id where b.hostel_id="+str(d.hostel_id))
        # data = cursor.fetchall()
        data = Students.objects.filter(hostel_id=d.hostel_id)
        data2 = Rooms.objects.filter(h_id=d.hostel_id)
        return render(request,'matron/student_list.html',{'data':data,'data2':data2,'d':d.hostel_id})
    else:
        return redirect('/home')

def outpass_request_m(request):
    if 'user' in request.session:
        d = Matron.objects.get(log_id=request.session['log_id'])
        cursor.execute("select s.*,r.hostel,o.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_outpass as o on o.student_id=s.log_id where s.hostel_id='"+str(d.hostel_id)+"' order by o.o_id desc")
        data = cursor.fetchall()
        return render(request,'matron/outpass_request.html',{'data':data})
    else:
        return redirect('/home')

def leave_request_m(request):
    if 'user' in request.session:
        d = Matron.objects.get(log_id=request.session['log_id'])
        cursor.execute("select s.*,r.hostel,l.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_leave as l on l.student_id=s.log_id where s.hostel_id='"+str(d.hostel_id)+"'order by l.l_id desc")
        data = cursor.fetchall()
        return render(request,'matron/leave_request.html',{'data':data})
    else:
        return redirect('/home')

def reply(request):
    if 'user' in request.session:
        if request.method == 'POST':
            c_id = request.POST['c_id']
            reply = request.POST['reply']
            Complaints.objects.filter(c_id=c_id).update(reply=reply)
            
            return redirect('/reply')
        else:
            d = Matron.objects.get(log_id=request.session['log_id'])
            cursor.execute("select s.*,r.hostel,l.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_complaints as l on l.student_id=s.log_id where s.hostel_id='"+str(d.hostel_id)+"'order by l.c_id desc")
            data = cursor.fetchall()
            return render(request,'matron/reply.html',{'data':data})
    else:
        return redirect('/home')


def add_messfee(request):
    if 'user' in request.session:
        if request.method == 'POST':
            s_id = request.POST['s_id']
            fee = request.POST['fee']
            Mess_Fee.objects.create(student_id=s_id,mess_fee=fee)
            messages.success(request, 'Added successfully..')
            return redirect('/add_messfee')
        else:
            m = Matron.objects.get(log_id=request.session['log_id'])
            data = Students.objects.filter(hostel_id=m.hostel_id)
            cursor.execute("select s.*,m.* from tb_student as s inner join tb_mess_fee as m on s.log_id=m.student_id where s.hostel_id="+str(m.hostel_id))
            data2 = cursor.fetchall()
            return render(request,'matron/add_messfee.html',{'data':data,'data2':data2})
    else:
        return redirect('/home')

def view_payments_m(request):
    if 'user' in request.session:
        ma = request.session['log_id']
        d = Matron.objects.get(log_id=ma)
        cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id where s.hostel_id="+str(d.hostel_id))
        data = cursor.fetchall()
        return render(request,'matron/view_payments.html',{'data':data})
    else:
        return redirect('/home')


def student_dues_m(request):
    if 'user' in request.session:
        ma = request.session['log_id']
        d = Matron.objects.get(log_id=ma)
        # cursor.execute("select s.*,r.hostel,p.* from tb_student as s inner join tb_hostel as r on s.hostel_id=r.h_id inner join tb_payment as p on p.student_id=s.log_id where p.next_pay_date< CURDATE() and s.hostel_id="+str(d.hostel_id))
        cursor.execute("select s.*,p.last_pay_date,p.next_pay_date,h.hostel from (SELECT student_id,last_pay_date,MAX(next_pay_date) AS next_pay_date from tb_payment group by student_id)p inner join tb_student as s on p.student_id=s.log_id inner join tb_hostel as h on s.hostel_id=h.h_id where p.next_pay_date< CURDATE() and s.hostel_id="+str(d.hostel_id))
        data2 = Rooms.objects.filter(h_id=d.hostel_id)
        data = cursor.fetchall()
        return render(request,'matron/student_dues.html',{'data':data,'data2':data2,'d':d.hostel_id})
    else:
        return redirect('/home')

def reset_password_m(request):
    if 'log_id' in request.session:
        log_id = request.session['log_id']
        if request.method == 'POST':
            opas = request.POST['old_password']
            password = request.POST['password']
            try:
                data = Login.objects.get(log_id=log_id)
                if data.password == opas:
                    Login.objects.filter(log_id=log_id).update(password=password)
                    messages.success(request, 'Your Password has been Reset successfully.....')
                    return redirect('/reset_password_m')
                else:
                    messages.success(request, 'Enter valid current password....!')
                    return redirect('/reset_password_m')
            except Exception:
                messages.success(request, 'Invalid User.....')
                return redirect('/reset_password_m')
        else:
            return render(request,'matron/reset_password.html')
    else:
        return redirect('/home')


def display_student_dues_m(request):
    str1=""
    hos=request.GET.get("hostel")
    room = request.GET.get("room")
    cursor.execute("select s.*,p.last_pay_date,p.next_pay_date,h.hostel from (SELECT student_id,last_pay_date,MAX(next_pay_date) AS next_pay_date from tb_payment group by student_id)p inner join tb_student as s on p.student_id=s.log_id inner join tb_hostel as h on s.hostel_id=h.h_id where p.next_pay_date< CURDATE() and s.hostel_id='"+str(hos)+"' and s.room_number="+str(room))
    data = cursor.fetchall()
    count=1
    for k in data:
    #    str1+="<tr><td>"+str(count)+"</td><td>Name :"+str(k[1])+"<br>Contact No.: "+str(k[3])+"<br>Batch: "+str(k[5])+"<br>Course: "+str(k[6])+"<br>Guardian Name: "+str(k[7])+"<br>Cotact No.: "+str(k[8])+"<br>Hostel :"+str(k[16])+"<br>Room No. :"+str(k[12])+"</td><td>"+str(k[14])+"</td><td>"+str(k[15])+"</td><td>Not Paid</td></tr>"                   
        str1+='''<tr>
              <td>'''+str(count)+'''</td><td>Name :'''+str(k[1])+'''<br>Contact No.: '''+str(k[3])+'''
              <br>Batch:'''+str(k[5])+'''<br>Course: '''+str(k[6])+'''<br>Guardian Name: '''+str(k[7])+'''
              <br>Cotact No.: '''+str(k[8])+'''<br>Hostel :'''+str(k[16])+'''<br>Room No. :'''+str(k[12])+'''</td><td>'''+str(k[14])+'''
              </td><td>'''+str(k[15])+'''</td><td>Not Paid</td></tr>'''                 

        count=count+1
                                    
    return HttpResponse(str1)


def display_student_dues_w(request):
    str1=""
    hostel=request.GET.get("hostel")
    cursor.execute("select s.*,p.last_pay_date,p.next_pay_date,h.hostel from (SELECT student_id,last_pay_date,MAX(next_pay_date) AS next_pay_date from tb_payment group by student_id)p inner join tb_student as s on p.student_id=s.log_id inner join tb_hostel as h on s.hostel_id=h.h_id where p.next_pay_date< CURDATE() and s.hostel_id="+str(hostel))
    data = cursor.fetchall()
    count=1
    for k in data:
    #    str1+="<tr><td>"+str(count)+"</td><td>Name :"+str(k[1])+"<br>Contact No.: "+str(k[3])+"<br>Batch: "+str(k[5])+"<br>Course: "+str(k[6])+"<br>Guardian Name: "+str(k[7])+"<br>Cotact No.: "+str(k[8])+"<br>Hostel :"+str(k[16])+"<br>Room No. :"+str(k[12])+"</td><td>"+str(k[14])+"</td><td>"+str(k[15])+"</td><td>Not Paid</td></tr>"                   
        str1+='''<tr>
              <td>'''+str(count)+'''</td><td>Name :'''+str(k[1])+'''<br>Contact No.: '''+str(k[3])+'''
              <br>Batch:'''+str(k[5])+'''<br>Course: '''+str(k[6])+'''<br>Guardian Name: '''+str(k[7])+'''
              <br>Cotact No.: '''+str(k[8])+'''<br>Hostel :'''+str(k[16])+'''<br>Room No. :'''+str(k[12])+'''</td><td>'''+str(k[14])+'''
              </td><td>'''+str(k[15])+'''</td><td>Not Paid</td></tr>'''                 

        count=count+1
                                    
    return HttpResponse(str1)



def display_room_student_m(request):
    str1=""
    room=request.GET.get("room")
    hostel = request.GET.get("hostel")
    data = Students.objects.filter(hostel_id=hostel,room_number=room)
    count=1
    for k in data:
       str1+="<tr><td>"+str(count)+"<td><img src='"+str(k.image)+"'width="'80px'" height="'80px'"></td><td>Name :"+str(k.name)+"<br> Address:"+str(k.address)+"<br> Email ID: "+str(k.email)+"<br>Contact No.: "+str(k.phone)+"</td><td>Batch: "+str(k.batch)+"<br>Course: "+str(k.course)+"</td><td>Guardian Name: "+str(k.guardian_name)+"<br>Cotact No.: "+str(k.guardian_number)+"</td><td>Room No. :"+str(k.room_number)+"</td><td><a href='"+str(k.id_proof)+"'style="'color: blue;">view</a></td></tr>"'                    
       count=count+1
                                    
    return HttpResponse(str1)



def display_hostel_student(request):
    str1=""
    hos=request.GET.get("hostel")
    cursor.execute("SELECT s.*,h.hostel FROM tb_student AS s INNER JOIN tb_hostel AS h ON s.hostel_id=h.h_id where s.hostel_id="+str(hos))
    data = cursor.fetchall()
    count=1
    for k in data:
       str1+="<tr><td>"+str(count)+"<td><img src='"+str(k[4])+"'width="'80px'" height="'80px'"></td><td>Name :"+str(k[1])+"<br> Address:"+str(k[2])+"<br> Email ID: "+str(k[10])+"<br>Contact No.: "+str(k[3])+"</td><td>Batch: "+str(k[5])+"<br>Course: "+str(k[6])+"</td><td>Guardian Name: "+str(k[7])+"<br>Cotact No.: "+str(k[8])+"</td><td>hostel :"+str(k[14])+"<br>Room No. :"+str(k[12])+"</td><td><a href='"+str(k[9])+"'style="'color: blue;">view</a></td></tr>"'                    
       count=count+1
                                    
    return HttpResponse(str1)

def display_room_student(request):
    str1=""
    hos=request.GET.get("hostel")
    room = request.GET.get("room")
    cursor.execute("SELECT s.*,h.hostel FROM tb_student AS s INNER JOIN tb_hostel AS h ON s.hostel_id=h.h_id where s.hostel_id='"+str(hos)+"' and s.room_number="+str(room))
    data = cursor.fetchall()
    count=1
    for k in data:
       str1+="<tr><td>"+str(count)+"<td><img src='"+str(k[4])+"'width="'80px'" height="'80px'"></td><td>Name :"+str(k[1])+"<br> Address:"+str(k[2])+"<br> Email ID: "+str(k[10])+"<br>Contact No.: "+str(k[3])+"</td><td>Batch: "+str(k[5])+"<br>Course: "+str(k[6])+"</td><td>Guardian Name: "+str(k[7])+"<br>Cotact No.: "+str(k[8])+"</td><td>hostel :"+str(k[14])+"<br>Room No. :"+str(k[12])+"</td><td><a href='"+str(k[9])+"'style="'color: blue;">view</a></td></tr>"'                    
       count=count+1
                                    
    return HttpResponse(str1)

def display_room(request):
    h_id = request.GET.get("h_id")
    try:
        sem = Rooms.objects.filter(~Q(vacancy=0),h_id=h_id)
    except Exception:
        data=[]
        data['error_message'] = 'error' 
        return JsonResponse(data)
    return JsonResponse(list(sem.values('r_id', 'room_number')), safe = False)


def check_username(request):
    username = request.GET.get("username")
    data = {
       'username_exists':      Login.objects.filter(username=username).exists(),
        'error':"This Username already has an account"
    }
    if(data["username_exists"]==False):
        data["success"]="Available"

    return JsonResponse(data)


def sign_out(request):
    logout(request)
    request.session.delete()
    return redirect('/home')


def master_reg(request):
    if request.method == 'POST':
        use = request.POST['username']
        pas =  request.POST['password']
        Login.objects.create(username=use,password=pas,role='admin',status=1)
        return redirect('/master_reg')
    else:
        return render(request,'master_reg.html')
# Create your views here.

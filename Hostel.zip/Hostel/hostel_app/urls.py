"""Hostel URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from .import views

urlpatterns = [
    path('', views.index),
    path('home/', views.home),
    path('home1/<str:v>', views.home),
    path('login/', views.login),
    path('student_login/', views.student_login),
    path('matron_login/', views.matron_login),
    path('warden_login/', views.warden_login),
    
    
    #master
    path('add_batch/', views.add_batch),
    path('up_batch/<int:b_id>',views.up_batch),
    path('update_batch/',views.update_batch),
    path('delete_batch/<int:b_id>', views.delete_batch),

    path('add_course/', views.add_course),
    path('up_course/<int:c_id>',views.up_course),
    path('update_course/',views.update_course),
    path('delete_course/<int:c_id>', views.delete_course),

    path('add_hostel/', views.add_hostel),
    path('up_hostel/<int:h_id>',views.up_hostel),
    path('update_hostel/',views.update_hostel),
    path('delete_hostel/<int:h_id>', views.delete_hostel),

    path('add_room/', views.add_room),
    path('up_room/<int:r_id>',views.up_room),
    path('update_room/',views.update_room),
    path('delete_room/<int:r_id>', views.delete_room),
    path('reset_password_a/', views.reset_password_a),

    path('add_fee/', views.add_fee),
    path('up_fee/<int:f_id>', views.up_fee),
    path('update_fee/', views.update_fee),
    path('delete_fee/<int:f_id>', views.delete_fee),

    path('add_warden/', views.add_warden),
    path('delete_warden/<int:w_id>', views.delete_warden),
    path('add_matron/', views.add_matron),
    path('delete_matron/<int:m_id>', views.delete_matron),

    path('add_student/', views.add_student),
    path('student_list/', views.student_list),
    path('student_list_a/', views.student_list_a),
    path('leave_request_a/', views.leave_request_a),
    path('outpass_request_a/', views.outpass_request_a),
    path('view_payments_a/', views.view_payments_a),
    path('student_dues_a/', views.student_dues_a),
    

    
    #student
    path('student_home/', views.student_home),
    path('view_fees/', views.view_fees),
    path('complaint/', views.complaint),
    path('view_reply/', views.view_reply),
    path('outpass_request/', views.outpass_request),
    path('view_outpass/', views.view_outpass),
    path('leave_request/', views.leave_request),
    path('view_leave/', views.view_leave),
    path('payment/', views.payment),
    path('view_payments_s/', views.view_payments_s),
    path('update_student/', views.update_student),
    path('scan_qr/', views.scan_qr),
    path('reset_password_s/', views.reset_password_s),

    #matron
    path('student_list_m/', views.student_list_m),
    path('leave_request_m/', views.leave_request_m),
    path('outpass_request_m/', views.outpass_request_m),
    path('reply/', views.reply),
    path('view_payments_m/', views.view_payments_m),
    path('student_dues_m/', views.student_dues_m),
    path('matron_profile/', views.matron_profile),
    path('reset_password_m/', views.reset_password_m),  
    path('add_messfee/', views.add_messfee),


    #Warden
    path('student_list_w/', views.student_list_w),

    path('leave_request_w/', views.leave_request_w),
    path('approve_leave/<int:l_id>', views.approve_leave),
    path('reject_leave/<int:l_id>', views.reject_leave),

    path('outpass_request_w/', views.outpass_request_w),
    path('approve_outpass/<int:o_id>', views.approve_outpass),
    path('reject_outpass/<int:o_id>', views.reject_outpass),

    path('view_payments_w/', views.view_payments_w),
    path('student_dues_w/', views.student_dues_w),

    path('warden_profile/', views.warden_profile),
    path('reset_password_w/', views.reset_password_w),

    path('display_student_dues_m/', views.display_student_dues_m),
    path('display_student_dues_w/', views.display_student_dues_w),
    path('display_room_student_m/', views.display_room_student_m),
    path('display_room_student/', views.display_room_student),
    path('display_hostel_student/', views.display_hostel_student),
    path('check_username/', views.check_username),
    path('display_room/', views.display_room),
    path('sign_out/', views.sign_out),
    path('master_reg/', views.master_reg),


]
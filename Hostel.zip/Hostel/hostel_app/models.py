from django.db import models

# Create your models here.
class Login(models.Model):
    log_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=20)
    password = models.TextField()
    role = models.CharField(max_length=10)
    status = models.IntegerField()
    class Meta:
        db_table = 'tb_Login'

class Batch(models.Model):
    b_id = models.AutoField(primary_key=True)
    batch = models.IntegerField()
    class Meta:
        db_table = 'tb_Batch'

class Course(models.Model):
    c_id = models.AutoField(primary_key=True)
    course = models.CharField(max_length=50)
    class Meta:
        db_table = 'tb_Course'

   
class Hostel(models.Model):
    h_id = models.AutoField(primary_key=True)
    hostel = models.CharField(max_length=20)
    class Meta:
        db_table = 'tb_Hostel'

class Rooms(models.Model):  
    r_id = models.AutoField(primary_key=True)
    h = models.ForeignKey(Hostel,on_delete=models.CASCADE)
    floor_number = models.IntegerField() 
    room_number = models.IntegerField() 
    beds = models.CharField(max_length=50)   
    vacancy = models.CharField(max_length=150)
    class Meta:
        db_table = 'tb_Rooms'

class Warden(models.Model):
    w_id = models.AutoField(primary_key=True)
    log =  models.ForeignKey(Login,on_delete=models.CASCADE)
    name = models.CharField(max_length=40)
    image = models.TextField()
    email = models.CharField(max_length=50)
    phone = models.BigIntegerField()
    address = models.TextField()
    class Meta:
        db_table = 'tb_Warden'

class Matron(models.Model):
    m_id = models.AutoField(primary_key=True)
    log =  models.ForeignKey(Login,on_delete=models.CASCADE)
    name = models.CharField(max_length=40)
    image = models.TextField()
    email = models.CharField(max_length=50)
    phone = models.BigIntegerField()
    address = models.TextField()
    hostel_id = models.IntegerField() 
    class Meta:
        db_table = 'tb_Matron'

class Students(models.Model):
    s_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    log =  models.ForeignKey(Login,on_delete=models.CASCADE)
    address = models.TextField()
    phone = models.BigIntegerField()
    image = models.CharField(max_length=150) 
    batch = models.CharField(max_length=150)
    course = models.CharField(max_length=150)  
    guardian_name = models.CharField(max_length=150)  
    guardian_number = models.CharField(max_length=150)  
    id_proof = models.CharField(max_length=150)  
    email = models.CharField(max_length=40)
    hostel_id = models.IntegerField() 
    room_number = models.IntegerField()
    join_date = models.CharField(max_length=20)
    class Meta:
        db_table = 'tb_Student'
 

class Hostel_fee(models.Model):  
    fee_id = models.AutoField(primary_key=True)
    electricity = models.IntegerField() 
    water = models.IntegerField() 
    rent = models.IntegerField() 
    total = models.IntegerField()
    class Meta:
        db_table = 'tb_Hostel_fee'

class Payment(models.Model):  
    p_id = models.AutoField(primary_key=True)
    student = models.ForeignKey(Login,on_delete=models.CASCADE)
    last_pay_date = models.CharField(max_length=50)
    next_pay_date= models.CharField(max_length=50)
    amount  = models.IntegerField(blank=True,null=True)
    status = models.CharField(max_length=20)
    class Meta:
        db_table = 'tb_Payment'

class Complaints(models.Model):
     c_id = models.AutoField(primary_key=True)
     student_id =  models.IntegerField() 
     hostel_id = models.IntegerField() 
     complaint = models.TextField()
     reply = models.TextField()
     class Meta:
        db_table = 'tb_Complaints'

class Outpass(models.Model):
     o_id = models.AutoField(primary_key=True)
     student_id =  models.IntegerField() 
     hostel_id = models.IntegerField()
     date = models.DateField()
     time = models.CharField(max_length=20)
     description = models.TextField()
     status = models.CharField(max_length=20)
     class Meta:
        db_table = 'tb_Outpass'

class Leave(models.Model):
     l_id = models.AutoField(primary_key=True)
     student_id =  models.IntegerField() 
     hostel_id = models.IntegerField()
     date = models.DateField()
     no_of_days = models.CharField(max_length=20)
     description = models.TextField()
     status = models.CharField(max_length=20)
     class Meta:
        db_table = 'tb_Leave'

class Mess_Fee(models.Model):
    mf_id = models.AutoField(primary_key=True)
    student = models.ForeignKey(Login,on_delete=models.CASCADE)
    mess_fee = models.IntegerField() 
    class Meta:
        db_table = 'tb_Mess_Fee'
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2023 at 09:49 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add batch', 7, 'add_batch'),
(26, 'Can change batch', 7, 'change_batch'),
(27, 'Can delete batch', 7, 'delete_batch'),
(28, 'Can view batch', 7, 'view_batch'),
(29, 'Can add complaints', 8, 'add_complaints'),
(30, 'Can change complaints', 8, 'change_complaints'),
(31, 'Can delete complaints', 8, 'delete_complaints'),
(32, 'Can view complaints', 8, 'view_complaints'),
(33, 'Can add course', 9, 'add_course'),
(34, 'Can change course', 9, 'change_course'),
(35, 'Can delete course', 9, 'delete_course'),
(36, 'Can view course', 9, 'view_course'),
(37, 'Can add hostel', 10, 'add_hostel'),
(38, 'Can change hostel', 10, 'change_hostel'),
(39, 'Can delete hostel', 10, 'delete_hostel'),
(40, 'Can view hostel', 10, 'view_hostel'),
(41, 'Can add hostel_fee', 11, 'add_hostel_fee'),
(42, 'Can change hostel_fee', 11, 'change_hostel_fee'),
(43, 'Can delete hostel_fee', 11, 'delete_hostel_fee'),
(44, 'Can view hostel_fee', 11, 'view_hostel_fee'),
(45, 'Can add login', 12, 'add_login'),
(46, 'Can change login', 12, 'change_login'),
(47, 'Can delete login', 12, 'delete_login'),
(48, 'Can view login', 12, 'view_login'),
(49, 'Can add payment', 13, 'add_payment'),
(50, 'Can change payment', 13, 'change_payment'),
(51, 'Can delete payment', 13, 'delete_payment'),
(52, 'Can view payment', 13, 'view_payment'),
(53, 'Can add warden', 14, 'add_warden'),
(54, 'Can change warden', 14, 'change_warden'),
(55, 'Can delete warden', 14, 'delete_warden'),
(56, 'Can view warden', 14, 'view_warden'),
(57, 'Can add students', 15, 'add_students'),
(58, 'Can change students', 15, 'change_students'),
(59, 'Can delete students', 15, 'delete_students'),
(60, 'Can view students', 15, 'view_students'),
(61, 'Can add rooms', 16, 'add_rooms'),
(62, 'Can change rooms', 16, 'change_rooms'),
(63, 'Can delete rooms', 16, 'delete_rooms'),
(64, 'Can view rooms', 16, 'view_rooms'),
(65, 'Can add matron', 17, 'add_matron'),
(66, 'Can change matron', 17, 'change_matron'),
(67, 'Can delete matron', 17, 'delete_matron'),
(68, 'Can view matron', 17, 'view_matron'),
(69, 'Can add leave', 18, 'add_leave'),
(70, 'Can change leave', 18, 'change_leave'),
(71, 'Can delete leave', 18, 'delete_leave'),
(72, 'Can view leave', 18, 'view_leave'),
(73, 'Can add outpass', 19, 'add_outpass'),
(74, 'Can change outpass', 19, 'change_outpass'),
(75, 'Can delete outpass', 19, 'delete_outpass'),
(76, 'Can view outpass', 19, 'view_outpass'),
(77, 'Can add mess_ fee', 20, 'add_mess_fee'),
(78, 'Can change mess_ fee', 20, 'change_mess_fee'),
(79, 'Can delete mess_ fee', 20, 'delete_mess_fee'),
(80, 'Can view mess_ fee', 20, 'view_mess_fee');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'hostel_app', 'batch'),
(8, 'hostel_app', 'complaints'),
(9, 'hostel_app', 'course'),
(10, 'hostel_app', 'hostel'),
(11, 'hostel_app', 'hostel_fee'),
(18, 'hostel_app', 'leave'),
(12, 'hostel_app', 'login'),
(17, 'hostel_app', 'matron'),
(20, 'hostel_app', 'mess_fee'),
(19, 'hostel_app', 'outpass'),
(13, 'hostel_app', 'payment'),
(16, 'hostel_app', 'rooms'),
(15, 'hostel_app', 'students'),
(14, 'hostel_app', 'warden'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-07-03 06:55:41.483717'),
(2, 'auth', '0001_initial', '2023-07-03 06:55:51.383889'),
(3, 'admin', '0001_initial', '2023-07-03 06:55:53.093432'),
(4, 'admin', '0002_logentry_remove_auto_add', '2023-07-03 06:55:53.128525'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2023-07-03 06:55:53.185680'),
(6, 'contenttypes', '0002_remove_content_type_name', '2023-07-03 06:55:53.865489'),
(7, 'auth', '0002_alter_permission_name_max_length', '2023-07-03 06:55:54.614644'),
(8, 'auth', '0003_alter_user_email_max_length', '2023-07-03 06:55:54.869338'),
(9, 'auth', '0004_alter_user_username_opts', '2023-07-03 06:55:54.929574'),
(10, 'auth', '0005_alter_user_last_login_null', '2023-07-03 06:55:55.956371'),
(11, 'auth', '0006_require_contenttypes_0002', '2023-07-03 06:55:56.036586'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2023-07-03 06:55:56.111816'),
(13, 'auth', '0008_alter_user_username_max_length', '2023-07-03 06:55:56.255218'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2023-07-03 06:55:56.433022'),
(15, 'auth', '0010_alter_group_name_max_length', '2023-07-03 06:55:56.592484'),
(16, 'auth', '0011_update_proxy_permissions', '2023-07-03 06:55:56.655610'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2023-07-03 06:55:57.239165'),
(18, 'hostel_app', '0001_initial', '2023-07-03 06:56:04.944767'),
(19, 'hostel_app', '0002_remove_rooms_image', '2023-07-03 06:56:05.817084'),
(20, 'hostel_app', '0003_complaints_hostel_id', '2023-07-03 06:56:06.124908'),
(21, 'hostel_app', '0004_leave_outpass', '2023-07-03 06:56:06.900964'),
(22, 'hostel_app', '0005_rename_o_id_leave_l_id', '2023-07-03 06:56:07.027353'),
(23, 'hostel_app', '0006_payment_amount', '2023-07-03 06:56:07.240867'),
(24, 'hostel_app', '0007_payment_status_alter_payment_amount', '2023-07-03 06:56:08.083153'),
(25, 'hostel_app', '0008_remove_matron_password_remove_students_password_and_more', '2023-07-03 06:56:08.548396'),
(26, 'hostel_app', '0009_remove_hostel_fee_food_mess_fee', '2023-07-03 06:56:10.139148'),
(27, 'hostel_app', '0010_rename_student_id_mess_fee_student', '2023-07-03 06:56:15.695387'),
(28, 'hostel_app', '0011_students_join_date', '2023-07-03 06:56:16.015238'),
(29, 'hostel_app', '0012_alter_payment_student_id', '2023-07-03 06:56:17.671021'),
(30, 'sessions', '0001_initial', '2023-07-03 06:56:18.116205'),
(31, 'hostel_app', '0013_rename_student_id_payment_student', '2023-07-03 07:05:58.507640');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('l90j3sgdz0wkf68ayxobcx8q70k78v6i', 'eyJ1c2VyIjoibWFudTEyIiwibG9nX2lkIjoyfQ:1qGEGc:OZiM0U_lZ7i627zoR6ttiKbRCBgTOO8CGMu-nZJHkeQ', '2023-07-17 07:46:38.104910');

-- --------------------------------------------------------

--
-- Table structure for table `tb_batch`
--

CREATE TABLE `tb_batch` (
  `b_id` int(11) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_batch`
--

INSERT INTO `tb_batch` (`b_id`, `batch`) VALUES
(1, 2021),
(2, 2022),
(3, 2023);

-- --------------------------------------------------------

--
-- Table structure for table `tb_complaints`
--

CREATE TABLE `tb_complaints` (
  `c_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `complaint` longtext NOT NULL,
  `reply` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_complaints`
--

INSERT INTO `tb_complaints` (`c_id`, `student_id`, `complaint`, `reply`, `hostel_id`) VALUES
(1, 4, 'Fan Is Not Working', 'we will check soon', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_course`
--

CREATE TABLE `tb_course` (
  `c_id` int(11) NOT NULL,
  `course` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course`
--

INSERT INTO `tb_course` (`c_id`, `course`) VALUES
(1, 'BBA'),
(2, 'BCA');

-- --------------------------------------------------------

--
-- Table structure for table `tb_hostel`
--

CREATE TABLE `tb_hostel` (
  `h_id` int(11) NOT NULL,
  `hostel` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_hostel`
--

INSERT INTO `tb_hostel` (`h_id`, `hostel`) VALUES
(1, 'Hostel 1'),
(2, 'Hostel 2'),
(3, 'Hostel 3');

-- --------------------------------------------------------

--
-- Table structure for table `tb_hostel_fee`
--

CREATE TABLE `tb_hostel_fee` (
  `fee_id` int(11) NOT NULL,
  `electricity` int(11) NOT NULL,
  `water` int(11) NOT NULL,
  `rent` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_hostel_fee`
--

INSERT INTO `tb_hostel_fee` (`fee_id`, `electricity`, `water`, `rent`, `total`) VALUES
(1, 500, 500, 1500, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `tb_leave`
--

CREATE TABLE `tb_leave` (
  `l_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_leave`
--

INSERT INTO `tb_leave` (`l_id`, `student_id`, `hostel_id`, `date`, `no_of_days`, `description`, `status`) VALUES
(1, 4, 1, '2023-07-04', '2', 'Description\r\n', 'Leave Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE `tb_login` (
  `log_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` longtext NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`log_id`, `username`, `password`, `role`, `status`) VALUES
(1, 'admin', '@admin', 'admin', 1),
(2, 'manu12', 'manu12@', 'warden', 1),
(3, 'anu12', 'anu12@', 'matron', 1),
(4, 'arun12', 'arun12@', 'student', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_matron`
--

CREATE TABLE `tb_matron` (
  `m_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `image` longtext NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_matron`
--

INSERT INTO `tb_matron` (`m_id`, `name`, `image`, `email`, `phone`, `address`, `hostel_id`, `log_id`) VALUES
(1, 'Anu', '/media/testimonial-1.jpg', 'anu@gmail.com', 7895463221, 'Anu Bhavan\r\nAdoor', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_mess_fee`
--

CREATE TABLE `tb_mess_fee` (
  `mf_id` int(11) NOT NULL,
  `mess_fee` int(11) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_mess_fee`
--

INSERT INTO `tb_mess_fee` (`mf_id`, `mess_fee`, `student_id`) VALUES
(1, 1000, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tb_outpass`
--

CREATE TABLE `tb_outpass` (
  `o_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_outpass`
--

INSERT INTO `tb_outpass` (`o_id`, `student_id`, `hostel_id`, `date`, `time`, `description`, `status`) VALUES
(1, 4, 1, '2023-07-04', '21:12', 'Description', 'Outpass Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `tb_payment`
--

CREATE TABLE `tb_payment` (
  `p_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `last_pay_date` varchar(50) NOT NULL,
  `next_pay_date` varchar(50) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_payment`
--

INSERT INTO `tb_payment` (`p_id`, `student_id`, `last_pay_date`, `next_pay_date`, `amount`, `status`) VALUES
(2, 4, '2023-07-03', '2023-09-01', 3500, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `tb_rooms`
--

CREATE TABLE `tb_rooms` (
  `r_id` int(11) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `room_number` int(11) NOT NULL,
  `beds` varchar(50) NOT NULL,
  `vacancy` varchar(150) NOT NULL,
  `h_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_rooms`
--

INSERT INTO `tb_rooms` (`r_id`, `floor_number`, `room_number`, `beds`, `vacancy`, `h_id`) VALUES
(1, 1, 100, '4', '3', 1),
(2, 1, 100, '4', '4', 2),
(3, 1, 101, '4', '4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_student`
--

CREATE TABLE `tb_student` (
  `s_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` longtext NOT NULL,
  `phone` bigint(20) NOT NULL,
  `image` varchar(150) NOT NULL,
  `batch` varchar(150) NOT NULL,
  `course` varchar(150) NOT NULL,
  `guardian_name` varchar(150) NOT NULL,
  `guardian_number` varchar(150) NOT NULL,
  `id_proof` varchar(150) NOT NULL,
  `email` varchar(40) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `room_number` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `join_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_student`
--

INSERT INTO `tb_student` (`s_id`, `name`, `address`, `phone`, `image`, `batch`, `course`, `guardian_name`, `guardian_number`, `id_proof`, `email`, `hostel_id`, `room_number`, `log_id`, `join_date`) VALUES
(1, 'Arun S', 'Arun Villa\r\nKonni', 8795641254, '/media/testimonial-2.jpg', '2022', 'BBA', 'Binu', '7895485623', '/media/cm.PNG', 'arun@gmail.com', 1, 100, 4, '2023-07-03');

-- --------------------------------------------------------

--
-- Table structure for table `tb_warden`
--

CREATE TABLE `tb_warden` (
  `w_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `image` longtext NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address` longtext NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_warden`
--

INSERT INTO `tb_warden` (`w_id`, `name`, `image`, `email`, `phone`, `address`, `log_id`) VALUES
(1, 'Manu', '/media/testimonial-3.jpg', 'manu@gmail.com', 9895463221, 'Manu Bhavan \r\nPathanamthitta', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `tb_batch`
--
ALTER TABLE `tb_batch`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `tb_complaints`
--
ALTER TABLE `tb_complaints`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tb_hostel`
--
ALTER TABLE `tb_hostel`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `tb_hostel_fee`
--
ALTER TABLE `tb_hostel_fee`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `tb_leave`
--
ALTER TABLE `tb_leave`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `tb_matron`
--
ALTER TABLE `tb_matron`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `tb_Matron_log_id_9fd40aa7_fk_tb_Login_log_id` (`log_id`);

--
-- Indexes for table `tb_mess_fee`
--
ALTER TABLE `tb_mess_fee`
  ADD PRIMARY KEY (`mf_id`),
  ADD KEY `tb_Mess_Fee_student_id_b89cb9c4_fk_tb_Login_log_id` (`student_id`);

--
-- Indexes for table `tb_outpass`
--
ALTER TABLE `tb_outpass`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `tb_payment`
--
ALTER TABLE `tb_payment`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `tb_Payment_student_id_id_40995879` (`student_id`);

--
-- Indexes for table `tb_rooms`
--
ALTER TABLE `tb_rooms`
  ADD PRIMARY KEY (`r_id`),
  ADD KEY `tb_Rooms_h_id_abfd737e_fk_tb_Hostel_h_id` (`h_id`);

--
-- Indexes for table `tb_student`
--
ALTER TABLE `tb_student`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `tb_Student_log_id_a40b66c5_fk_tb_Login_log_id` (`log_id`);

--
-- Indexes for table `tb_warden`
--
ALTER TABLE `tb_warden`
  ADD PRIMARY KEY (`w_id`),
  ADD KEY `tb_Warden_log_id_f8a43515_fk_tb_Login_log_id` (`log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tb_batch`
--
ALTER TABLE `tb_batch`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_complaints`
--
ALTER TABLE `tb_complaints`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_course`
--
ALTER TABLE `tb_course`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_hostel`
--
ALTER TABLE `tb_hostel`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_hostel_fee`
--
ALTER TABLE `tb_hostel_fee`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_leave`
--
ALTER TABLE `tb_leave`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_login`
--
ALTER TABLE `tb_login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_matron`
--
ALTER TABLE `tb_matron`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_mess_fee`
--
ALTER TABLE `tb_mess_fee`
  MODIFY `mf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_outpass`
--
ALTER TABLE `tb_outpass`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_payment`
--
ALTER TABLE `tb_payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_rooms`
--
ALTER TABLE `tb_rooms`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_student`
--
ALTER TABLE `tb_student`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_warden`
--
ALTER TABLE `tb_warden`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `tb_matron`
--
ALTER TABLE `tb_matron`
  ADD CONSTRAINT `tb_Matron_log_id_9fd40aa7_fk_tb_Login_log_id` FOREIGN KEY (`log_id`) REFERENCES `tb_login` (`log_id`);

--
-- Constraints for table `tb_mess_fee`
--
ALTER TABLE `tb_mess_fee`
  ADD CONSTRAINT `tb_Mess_Fee_student_id_b89cb9c4_fk_tb_Login_log_id` FOREIGN KEY (`student_id`) REFERENCES `tb_login` (`log_id`);

--
-- Constraints for table `tb_payment`
--
ALTER TABLE `tb_payment`
  ADD CONSTRAINT `tb_Payment_student_id_8c47b9ad_fk_tb_Login_log_id` FOREIGN KEY (`student_id`) REFERENCES `tb_login` (`log_id`);

--
-- Constraints for table `tb_rooms`
--
ALTER TABLE `tb_rooms`
  ADD CONSTRAINT `tb_Rooms_h_id_abfd737e_fk_tb_Hostel_h_id` FOREIGN KEY (`h_id`) REFERENCES `tb_hostel` (`h_id`);

--
-- Constraints for table `tb_student`
--
ALTER TABLE `tb_student`
  ADD CONSTRAINT `tb_Student_log_id_a40b66c5_fk_tb_Login_log_id` FOREIGN KEY (`log_id`) REFERENCES `tb_login` (`log_id`);

--
-- Constraints for table `tb_warden`
--
ALTER TABLE `tb_warden`
  ADD CONSTRAINT `tb_Warden_log_id_f8a43515_fk_tb_Login_log_id` FOREIGN KEY (`log_id`) REFERENCES `tb_login` (`log_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
